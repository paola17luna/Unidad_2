package com.example.practica4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText nombre, ap, am, edad, correo, colonia;
    Button aceptar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre =(EditText) findViewById(R.id.et1);
        ap =(EditText) findViewById(R.id.et2);
        am =(EditText) findViewById(R.id.et3);
        edad =(EditText) findViewById(R.id.et4);
        correo =(EditText) findViewById(R.id.et5);
        colonia =(EditText) findViewById(R.id.et6);
        aceptar = (Button) findViewById(R.id.bt1);

        aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String n = nombre.getText().toString();
                String app = ap.getText().toString();
                String apm = am.getText().toString();
                String e = edad.getText().toString();
                String email = correo.getText().toString();
                String c = colonia.getText().toString();

                Intent i = new Intent(MainActivity.this, Mostrar.class);

                i.putExtra("n", n);
                i.putExtra("app", app);
                i.putExtra("apm", apm);
                i.putExtra("e", e);
                i.putExtra("email", email);
                i.putExtra("c", c);

                startActivity(i);

            }
        });
    }

    public void limpiar(View view) {
        nombre.setText("");
        ap.setText("");
        am.setText("");
        edad.setText("");
        correo.setText("");
        colonia.setText("");
    }
}