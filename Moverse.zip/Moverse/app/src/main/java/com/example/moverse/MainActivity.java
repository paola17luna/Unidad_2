package com.example.moverse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button v2,v3,v4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //----------------------------------------------------------------------------------//

        v2=(Button) findViewById(R.id.bt1);

        v2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ventana_2.class));
            }
        });
        //----------------------------------------------------------------------------------//
        v3=(Button) findViewById(R.id.bt2);

        v3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ventana_3.class));
            }
        });
        //----------------------------------------------------------------------------------//
        v4=(Button) findViewById(R.id.bt3);

        v4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ventanafinal.class));
            }
        });
        //----------------------------------------------------------------------------------//
    }
}