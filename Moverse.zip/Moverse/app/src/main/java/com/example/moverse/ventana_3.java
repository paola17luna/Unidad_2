package com.example.moverse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ventana_3 extends AppCompatActivity {

    Button s2,v2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana3);


        //----------------------------------------------------------------------------------//
        s2=(Button) findViewById(R.id.btns2);

        s2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ventana_3.this, ventanafinal.class));
            }
        });
        //----------------------------------------------------------------------------------//
        v2=(Button) findViewById(R.id.btnv2);

        v2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ventana_3.this, MainActivity.class));
            }
        });
        //----------------------------------------------------------------------------------//
    }
}